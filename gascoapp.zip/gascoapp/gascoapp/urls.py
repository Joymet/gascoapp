
from Gascoaplication import views
from django.urls import path

urlpatterns = [
    path('', views.index, name='index'),
    path('ingresar_solicitud/', views.ingresar_solicitud, name='ingresar_solicitud'),
    path('lista-solicitudes/', views.lista_solicitudes, name='lista_solicitudes'),
    path('detalle_solicitud/<int:solicitud_id>/', views.detalle_solicitud, name='detalle_solicitud'),
    path('buscar_solicitud/', views.buscar_solicitud, name='buscar_solicitud'),
    path('editar_solicitud/<int:solicitud_id>/', views.editar_solicitud, name='editar_solicitud'),
    path('eliminar_solicitud/<int:solicitud_id>/', views.eliminar_solicitud, name='eliminar_solicitud'),
    path('cambiar_estado/<int:solicitud_id>/', views.cambiar_estado, name='cambiar_estado'),
]