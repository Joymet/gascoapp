function validarSolicitud() {
    var rut = document.getElementById("id_rut").value;
    var nombre = document.getElementById("id_nombre").value;
    var apellidos = document.getElementById("id_apellidos").value;
    var direccion = document.getElementById("id_direccion").value;
    var telefono = document.getElementById("id_telefono").value;
    var comuna = document.getElementById("id_comuna").value;

    document.getElementById("error_rut").textContent = "";
    document.getElementById("error_nombre").textContent = "";
    document.getElementById("error_apellidos").textContent = "";
    document.getElementById("error_direccion").textContent = "";
    document.getElementById("error_telefono").textContent = "";
    document.getElementById("error_comuna").textContent = "";

    var tieneErrores = false;

    if (rut.trim() === "") {
        document.getElementById("error_rut").textContent = "El campo RUT no puede estar en blanco.";
        tieneErrores = true;
    }

    if (nombre.trim() === "") {
        document.getElementById("error_nombre").textContent = "El campo Nombre no puede estar en blanco.";
        tieneErrores = true;
    }

    if (apellidos.trim() === "") {
        document.getElementById("error_apellidos").textContent = "El campo Apellidos no puede estar en blanco.";
        tieneErrores = true;
    }

    if (direccion.trim() === "") {
        document.getElementById("error_direccion").textContent = "El campo Dirección es obligatorio.";
        tieneErrores = true;
    }

    if (telefono.trim() === "" || isNaN(telefono) || telefono.length !== 9 || telefono[0] !== '9') {
        document.getElementById("error_telefono").textContent = "Ingresa un número de teléfono válido.";
        tieneErrores = true;
    }

    if (comuna.trim() === "Elija su comuna") {
        document.getElementById("error_comuna").textContent = "Debe seleccionar una comuna.";
        tieneErrores = true;
    }

    if (tieneErrores) {
        return false;
    }

    return true;
}
