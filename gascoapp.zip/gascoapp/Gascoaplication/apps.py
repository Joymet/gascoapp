from django.apps import AppConfig


class GascoaplicationConfig(AppConfig):
    name = 'Gascoaplication'
