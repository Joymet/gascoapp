from django.db import models
from django.utils import timezone

class Solicitud(models.Model):
    ESTADO_CHOICES = (
        ('PENDIENTE', 'Pendiente'),
        ('ACEPTADA', 'Aceptada'),
        ('RECHAZADA', 'Rechazada'),
        ('EXPIRADA', 'Expirada'),
    )
     
    rut = models.CharField(max_length=15, blank=False)
    nombre = models.CharField(max_length=100, blank=False)
    apellidos = models.CharField(max_length=100, blank=False)
    direccion = models.CharField(max_length=200, blank=False)
    telefono = models.CharField(max_length=20, blank=False)
    comuna = models.CharField(max_length=100, blank=False)
    fecha_solicitud = models.DateTimeField(default=timezone.now)
    fecha_aceptacion = models.DateTimeField(null=True, blank=True)
    estado = models.CharField(max_length=10, choices=ESTADO_CHOICES, default='PENDIENTE')

    def __str__(self):
        return f"{self.rut} - {self.nombre} {self.apellidos}"
