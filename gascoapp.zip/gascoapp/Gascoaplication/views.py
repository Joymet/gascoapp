from datetime import datetime, timedelta
from django.shortcuts import render
from django.shortcuts import render, redirect, get_object_or_404
from django import forms
from .models import Solicitud
from django.core.validators import RegexValidator, MinLengthValidator


def index(request):
    return render(request, 'index.html')

class CustomTextInput(forms.TextInput):
    def render(self, name, value, attrs=None, renderer=None):
        rendered = super().render(name, value, attrs, renderer)
        errors = self.errors
        if errors:
            error_list = ' '.join(errors)
            rendered += f'<span class="error-text">{error_list}</span>'
        return rendered
    

class SolicitudForm(forms.ModelForm):
    rut = forms.CharField(
        validators=[
            RegexValidator(
                regex=r'^\d{7,8}-[\dKk]$',
                message='El RUT debe estar en el formato correcto (Ejemplo: 12345678-9).'
            )
        ],
        widget=forms.TextInput(attrs={'class': 'xd rut'})
    )

    nombre = forms.CharField(
        validators=[
            MinLengthValidator(
                limit_value=3,
                message='El nombre debe tener al menos 3 caracteres.'
            )
        ],
        widget=forms.TextInput(attrs={'class': 'xd'})
    )

    apellidos = forms.CharField(
        widget=forms.TextInput(attrs={'class': 'xd'})
    )

    direccion = forms.CharField(
        widget=forms.TextInput(attrs={'class': 'xd'})
    )

    
    comuna = forms.CharField(
        widget=forms.TextInput(attrs={'class': 'xd'})
    )


    telefono = forms.CharField(
        validators=[
            RegexValidator(
                regex=r'^\d{9}$',
                message='El número de teléfono debe contener 9 dígitos.'
            )
        ],
        widget=forms.TextInput(attrs={'class': 'xd'})
    )

    class Meta:
        model = Solicitud
        fields = ['rut', 'nombre', 'apellidos', 'direccion', 'telefono', 'comuna']
        widget=forms.TextInput(attrs={'class': 'xd'})
        

def ingresar_solicitud(request):
    if request.method == 'POST':
        form = SolicitudForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('lista_solicitudes')
    else:
        form = SolicitudForm()
    return render(request, 'ingresar_solicitud.html', {'form': form})

def lista_solicitudes(request):
    solicitudes = Solicitud.objects.all()
    hoy = datetime.now().date()
   
    for solicitud in solicitudes:
        if solicitud.estado == 'ACEPTADA' and solicitud.fecha_aceptacion is not None and (hoy - solicitud.fecha_aceptacion.date()).days >= 30:
            solicitud.estado = 'EXPIRADA'
            solicitud.save()

    return render(request, 'lista_solicitudes.html', {'solicitudes': solicitudes})

def detalle_solicitud(request, solicitud_id):
    solicitud = get_object_or_404(Solicitud, pk=solicitud_id)
    return render(request, 'detalle_solicitud.html', {'solicitud': solicitud})

def buscar_solicitud(request):
    if request.method == 'GET':
        rut = request.GET.get('rut', '')
        solicitudes = Solicitud.objects.filter(rut=rut)
        return render(request, 'buscar_solicitud.html', {'solicitudes': solicitudes})
    return render(request, 'buscar_solicitud.html')

def editar_solicitud(request, solicitud_id):
    solicitud = get_object_or_404(Solicitud, pk=solicitud_id)
    if request.method == 'POST':
        form = SolicitudForm(request.POST, instance=solicitud)
        if form.is_valid():
            form.save()
            return redirect('lista_solicitudes')
    else:
        form = SolicitudForm(instance=solicitud)
    return render(request, 'editar_solicitud.html', {'form': form, 'solicitud': solicitud})

def eliminar_solicitud(request, solicitud_id):
    solicitud = get_object_or_404(Solicitud, pk=solicitud_id)
    if request.method == 'POST':
        solicitud.delete()
        return redirect('lista_solicitudes')
    return render(request, 'eliminar_solicitud.html', {'solicitud': solicitud})

def cambiar_estado(request, solicitud_id):
    solicitud = get_object_or_404(Solicitud, pk=solicitud_id)

    if request.method == 'POST':
        nuevo_estado = request.POST.get('nuevo_estado')
        if nuevo_estado in [choice[0] for choice in Solicitud.ESTADO_CHOICES]:
            solicitud.estado = nuevo_estado
            solicitud.save()
            return redirect('detalle_solicitud', solicitud_id=solicitud_id)

    return render(request, 'cambiar_estado.html', {'solicitud': solicitud})

